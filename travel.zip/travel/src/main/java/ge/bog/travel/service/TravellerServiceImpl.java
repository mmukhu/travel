package ge.bog.travel.service;

import ge.bog.travel.model.TravellerDto;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TravellerServiceImpl implements TravellerService{
    private List<TravellerDto> travellers = new ArrayList<>();

    // GET - აიდის მიხედვით ბრუნდება შესაბამისი თრეველერი
    public TravellerDto getTraveller(Long id) {
        TravellerDto result = null;
        for (TravellerDto traveller : travellers) {
            if (traveller.getId().equals(id)) {
                result = traveller;
                break;
            }
        }
        return result;
    }

    // GET - სახელის მიხედვით ბრუნდება შესაბამისი თრეველერი
    public List<TravellerDto> getTravellers(String name) {
        List<TravellerDto> result = new ArrayList<>(); // ვაბრუნებთ ლისტს რადგან ერთი სახელი შეიზლება ბევრს ქვია
        if(name == null){
            result = travellers;
        }else{
            for (TravellerDto traveller : travellers) {
                if (traveller.getName().equals(name)) {
                    result.add(traveller);
                }
            }
        }
        return result;
    }

    // UPDATE
    public void updateTraveller(Long id, TravellerDto travellerDto) {
        for (TravellerDto traveller : travellers) {
            if(traveller.getId().equals(id)){
                traveller.setName(travellerDto.getName());
                traveller.setLastName(travellerDto.getLastName());
                break;
            }
        }
    }

    // DELETE
    public void deleteTraveller(Long id) {
        for (TravellerDto traveller : travellers) {
            if (traveller.getId().equals(id)) {
                travellers.remove(traveller);
                break;
            }
        }
    }

    // CREATE
    @Override
    public void createTraveller(TravellerDto travellerDto) {
        travellers.add(travellerDto);
    }
}


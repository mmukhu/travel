package ge.bog.travel.service;

import ge.bog.travel.model.TravellerDto;

import java.util.List;

public interface TravellerService {
    TravellerDto getTraveller(Long id);

    List<TravellerDto> getTravellers(String name);

    void updateTraveller(Long id, TravellerDto travellerDto);

    void deleteTraveller(Long id);

    void createTraveller(TravellerDto travellerDto);
}

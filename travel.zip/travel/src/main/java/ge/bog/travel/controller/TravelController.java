package ge.bog.travel.controller;

import ge.bog.travel.model.TravellerDto;
import ge.bog.travel.service.TravellerService;
import ge.bog.travel.service.TravellerServiceImpl;
import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/travellers")

public class TravelController {

    @Autowired
    private TravellerService travellerService;

    // GET ტიპის რექსვესთი
    // რომ შევიყვან localhost:9090/currency/test ამ რექვესთზე დამიწერს - works!
    // POST რექვესთის შემთხვევაში პარამეტრები დამალულია, მაგალითად არ მიწერია ურლ-ში
    // localhost:9090/password=abc

    // ანუ სულ გვაქვს ესეთი რიქვესთები:
    // GET - რამის წამოღება თუ გვინდა
    // POST - რამის შექმნა თუ გვინდა
    // PUT, PATCH - რამე მონაცემის ჩამატება თუ გვინდა/აფდეითი
    // DELETE - წაშლა duh

   /* @GetMapping
    // ყველა თრეველერი ბრუნდება
    public ResponseEntity<List<TravellerDto>> getTravellers() {
        // new ResponseEntity<String>("works",HttpStatus.ok); // ასეც შეიძლებოდა დაწერა
        return ResponseEntity.ok(travellers);
    }*/

    @GetMapping("/{id}")
    // აიდის მიხედვით ბრუნდება შესაბამისი თრეველერი
    public ResponseEntity<TravellerDto> getTraveller(@NonNull @PathVariable(value = "id") Long id) {
        TravellerDto result = travellerService.getTraveller(id);
        return ResponseEntity.ok(result);
    }



    @GetMapping
    // სახელის მიხედვით ბრუნდება შესაბამისი თრეველერი
    // path variable vs request parameter - პას ვერიებლი სლეშით რო იწერება, მაგ: customer/5 ანუ მეხუთე კლიენტი
    // ხოლო რიქვესთ პარამეტრი კითხვის ნიშნით როა ეგაა, რომ შემყავს.
    public ResponseEntity<List<TravellerDto>> getTravellers(@RequestParam(required = false) String name) {
        List<TravellerDto> result = travellerService.getTravellers(name);
        return ResponseEntity.ok(result);
    }


    // POST ტიპის რიქვესთი
    @PostMapping
    public ResponseEntity<Void> createTraveller(@RequestBody TravellerDto travellerDto){
        travellerService.createTraveller(travellerDto);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    // UPDATE ტიპის რიქვესთი
    // გადაეცემა TravellerDto ტიპის ობიექტი თავისი აიდით და მაგ თრაველერს დააფდეითებს
    // შემოწმება: ლისტში რომელი თრეველერის აიდიც დაემთხვევევა გადაცემული თრეველერის აიდის
    // მაგას ვააფდეითებთ
    @PutMapping("/{id}")
    public ResponseEntity<TravellerDto> updateTraveller(@NonNull @PathVariable Long id,
                                                        @RequestBody TravellerDto travellerDto){

        travellerService.updateTraveller(id, travellerDto);
        return ResponseEntity.ok(travellerDto);
    }


    // DELETE რექვესთი
    // გადაეცემა აიდი, პოულობს ობიექტს, შლის
    @DeleteMapping("/{id}")
    // აიდის მიხედვით ბრუნდება შესაბამისი თრეველერი
    public ResponseEntity<Void> deleteTraveller(@NonNull @PathVariable(value = "id") Long id) {

        travellerService.deleteTraveller(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}

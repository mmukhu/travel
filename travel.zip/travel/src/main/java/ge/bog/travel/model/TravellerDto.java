package ge.bog.travel.model;

import lombok.Data;

@Data
public class TravellerDto {
   private Long id;

    private String name;

    private String lastName;
}

package ge.bog.travel.service;

import ge.bog.travel.model.Root;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.HashMap;
import java.util.Map;

@Service

public class ApiService {
    @Value("${templates.accessible.services.url}")
    private String templatesAccessibleServicesUrl;

    private final WebClient webClient = WebClient.create();

    /* TODO:
       Using parameters that are stored in Map, Method returns API response.
     * */
    public Root getApiServices(String city, String stateCode, String countryCode){

        Map<String,String> requestParameters = new HashMap<>();
        requestParameters.put("city name", city);
        requestParameters.put("state code", stateCode);
        requestParameters.put("country code", countryCode);

        Root response = webClient.get()
                .uri(templatesAccessibleServicesUrl, requestParameters)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .retrieve()
                .bodyToFlux(Root.class).blockFirst();
        return response;
    }
}

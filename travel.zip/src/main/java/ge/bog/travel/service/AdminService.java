package ge.bog.travel.service;

import org.springframework.stereotype.Service;


public interface AdminService {

    void addAdmin(Long id, Long admin);

    void removeAdmin(Long id, Long admin);

}

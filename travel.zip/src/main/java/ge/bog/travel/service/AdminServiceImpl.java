package ge.bog.travel.service;


import ge.bog.travel.domain.Admin;
import ge.bog.travel.repository.AdminRepository;
import ge.bog.travel.repository.TouristRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AdminServiceImpl implements AdminService{
    private final AdminRepository adminRepository;
    private final TouristRepository touristRepository;


     /*TODO:
       Check if admin is the one who's trying to add new admin. If that's the case check if admin already
       exists. If that's not the case add new admin to repository.
    * */

    @Override
    public void addAdmin(Long id, Long oldAdmin) {
            if (adminExists(oldAdmin)) {
                if (touristRepository.existsById(id)) {
                    if (adminRepository.existsById(id)) {
                        log.info("Admin already exists");
                    } else {
                        Admin newAdmin = Admin.builder()
                                .id(id)
                                .build();
                        adminRepository.save(newAdmin);
                    }
                } else {
                    log.info("Sorry, user does not exist");
                }
            } else {
                log.info("Bad Request! Not an admin!");
                log.info("" + adminRepository.findById(oldAdmin).toString());
            }
        }

     /*TODO:
       Check if total current number of admins is at least 1.
       Check if the one who's trying to remove admin is admin.
       If that's the case, remove admin.
    * */

    @Override
    public void removeAdmin(Long id, Long oldAdmin) {
        if(adminRepository.count() > 1){
            if(adminExists(oldAdmin)){
                Admin remover = Admin.builder()
                        .id(id)
                        .build();
                adminRepository.delete(remover);
            }else{
                log.info("Bad Request!");
            }
        }else{
            log.info("Only admin. can not delete");
        }
    }

    public boolean adminExists(Long oldAdmin){
        if(adminRepository.existsById(oldAdmin)){
            return true;
        }else {
            return false;}
    }
}

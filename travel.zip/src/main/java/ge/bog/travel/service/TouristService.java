package ge.bog.travel.service;

import ge.bog.travel.model.TouristDto;

public interface TouristService {

    TouristDto getTourist(Long id, Long admin);

    TouristDto createTourist(Long id,TouristDto touristDto);

    TouristDto updateTourist(Long id, TouristDto touristDto);

    void deleteTourist(Long id,TouristDto touristDto);
}

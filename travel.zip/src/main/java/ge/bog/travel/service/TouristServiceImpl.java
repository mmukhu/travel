package ge.bog.travel.service;


import ge.bog.travel.domain.Tourist;
import ge.bog.travel.model.TouristDto;
import ge.bog.travel.model.TouristMapper;
import ge.bog.travel.repository.AdminRepository;
import ge.bog.travel.repository.TouristRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class TouristServiceImpl implements TouristService{

    private final TouristRepository touristRepository;
    private final AdminService adminService;
    private final AdminRepository adminRepository;
    private final ApiService apiService;

    /* TODO:
       Checks if user trying to get data is either admin or user trying to
       get their own data. If that's the case, returns touristDto Object.
     */
    @Override
    public TouristDto getTourist(Long id,Long admin){
        if(adminRepository.existsById(admin) || admin.equals(id)){
            Optional<Tourist> tourists =  touristRepository.findById(id);
            Tourist tourist = tourists.orElseThrow(() -> new RuntimeException("Not found"));
            TouristDto touristDto = TouristMapper.toDto(tourist);
            return touristDto;
        }else{
            log.info("Bad request! Not an admin");
            return null;
        }
    }

    /* TODO:
       Checks if user trying to create new user is admin.
       If that's the case, creates new user.
     */

    @Override
    public TouristDto createTourist(Long id,TouristDto touristDto){
        if(adminRepository.existsById(id)){
            double lat = apiService.getApiServices(touristDto.getCity(),touristDto.getStateCode(), touristDto.getCountryCode()).lat;
            double lon = apiService.getApiServices(touristDto.getCity(),touristDto.getStateCode(), touristDto.getCountryCode()).lon;

            Tourist newTourist = Tourist.builder()
                    .idNum(touristDto.getIdNum())
                    .name(touristDto.getName())
                    .city(touristDto.getCity())
                    .stateCode(touristDto.getStateCode())
                    .countryCode(touristDto.getCountryCode())
                    .date(touristDto.getDate())
                    .lat((long) lat)
                    .lon((long) lon)
                    .build();

            touristRepository.save(newTourist);
            TouristDto responseDto = TouristMapper.toDto(newTourist);
            return responseDto;
        }else{
            log.info("Bad request! Not an admin");
            return null;
        }
    }

    /* TODO:
       Checks if user trying to update data is either admin or user trying to
       get their own data. Checks if user exists with that id.
       If that's the case, saves new touristDto Object.
     */
    @Override
    public TouristDto updateTourist(Long id, TouristDto touristDto){
        if(adminRepository.existsById(id) || touristDto.getId().equals(id)){
            if(touristRepository.existsById(touristDto.getId())){
                Tourist tourist = TouristMapper.toEntity(touristDto.getId(),touristDto);
                Tourist entity = touristRepository.save(tourist);
                TouristDto responseDto = TouristMapper.toDto(entity);
                return responseDto;
            }else{
                log.info("User does not exist!");
                return null;
            }
        }else{
            log.info("Bad Request! Not an admin or correct user.");
        }
        return null;
    }

    /* TODO:
       Checks if user trying to delete data is either admin or user trying to
       get their own data. If that's the case, method deletes user.
     */

    @Override
    public void deleteTourist(Long id, TouristDto touristDto){
        if(adminRepository.existsById(id) || id.equals(touristDto.getId())){
            if(touristRepository.existsById(touristDto.getId())){
                Tourist tourist = TouristMapper.toEntity(touristDto.getId(),touristDto);
                touristRepository.delete(tourist);
            }else{
                log.info("User does not exist!");
            }
        }else{
            log.info("Bad Request! Not an admin or correct user.");
        }
    }
}

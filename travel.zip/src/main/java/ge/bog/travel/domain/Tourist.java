package ge.bog.travel.domain;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "TOURISTS")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Tourist {
    @Id
    @SequenceGenerator(name = "TOURIST_SEQ", sequenceName = "TOURIST_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TOURIST_SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "ID_NUM")
    private String idNum;

    @Column(name = "NAME")
    private String name;

    @Column(name = "CITY")
    private String city;

    @Column(name = "STATE_CODE")
    private String stateCode;

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "VISIT_DATE")
    private String date;

    @Column(name = "LATITUDE")
    private Long lat;

    @Column(name = "LONGITUDE")
    private Long lon;
}
package ge.bog.travel.controller;


import ge.bog.travel.model.TouristDto;
import ge.bog.travel.service.TouristService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tourists")
@RequiredArgsConstructor
public class TouristController {

    private final TouristService touristService;

    @GetMapping("/{admin}/{id}")
    public ResponseEntity<TouristDto> getTourist(@NonNull @PathVariable(value = "id") Long id,
                                                 @NonNull @PathVariable(value = "admin") Long admin){
        TouristDto result = touristService.getTourist(id,admin);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/{id}")
    public ResponseEntity<TouristDto> createTourist(@NonNull @PathVariable(value = "id") Long id,
                                                    @RequestBody TouristDto touristDto){
        TouristDto result = touristService.createTourist(id,touristDto);
        return ResponseEntity.ok(result);
    }
    @PutMapping("update/{id}")
    public ResponseEntity<TouristDto> updateTourist(@NonNull @PathVariable(value = "id") Long id,
                                                    @RequestBody TouristDto touristDto){
        TouristDto result = touristService.updateTourist(id,touristDto);
        return ResponseEntity.ok(result);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTourist(@NonNull @PathVariable(value = "id") Long id,
                                              @RequestBody TouristDto touristDto) {
        touristService.deleteTourist(id,touristDto);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
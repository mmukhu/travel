package ge.bog.travel.controller;


import ge.bog.travel.domain.Admin;
import ge.bog.travel.service.AdminService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admins")
@RequiredArgsConstructor
public class AdminController {
    private final AdminService adminService;

    @PostMapping("/{id}/{oldAdmin}")
    public ResponseEntity<Void> addAdmin(@NonNull @PathVariable(value = "id") Long id,
                                         @NonNull @PathVariable(value = "oldAdmin") Long oldAdmin){
        adminService.addAdmin(id,oldAdmin);
        return  new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/{id}/{oldAdmin}")
    public ResponseEntity<Void> removeAdmin(@NonNull @PathVariable(value = "id") Long id,
                                            @NonNull @PathVariable(value = "oldAdmin") Long oldAdmin){
        adminService.removeAdmin(id,oldAdmin);
        return  new ResponseEntity<>(HttpStatus.OK);
    }
}

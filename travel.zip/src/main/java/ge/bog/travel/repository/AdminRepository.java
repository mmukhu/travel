package ge.bog.travel.repository;

import ge.bog.travel.domain.Admin;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface AdminRepository extends CrudRepository<Admin, Long> {
    Optional<Admin> findById(Long id);

    boolean existsById(Long id);

    long count();
}

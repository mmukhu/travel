package ge.bog.travel.repository;

import ge.bog.travel.domain.Tourist;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface TouristRepository extends CrudRepository<Tourist, Long> {

    Optional<Tourist> findById(Long id);

    boolean existsById(Long id);
}

package ge.bog.travel.model;

import lombok.*;

import javax.persistence.Column;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TouristDto {

    private Long id;

    private String idNum;

    private String name;

    private String city;

    private String stateCode;

    private String countryCode;

    private String date;

    private Long lat;

    private Long lon;
}

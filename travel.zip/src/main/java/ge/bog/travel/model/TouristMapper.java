package ge.bog.travel.model;

import ge.bog.travel.domain.Tourist;

public class TouristMapper {

    public static TouristDto toDto(Tourist tourist) {
        TouristDto touristDto = TouristDto.builder()
                .id(tourist.getId())
                .idNum(tourist.getIdNum())
                .name(tourist.getName())
                .city(tourist.getCity())
                .stateCode(tourist.getStateCode())
                .countryCode(tourist.getCountryCode())
                .date(tourist.getDate())
                .lat(tourist.getLat())
                .lon(tourist.getLon())
                .build();
        return touristDto;
    }

    public static Tourist toEntity(Long id, TouristDto touristDto) {
        Tourist tourist = Tourist.builder()
                .id(id)
                .idNum(touristDto.getIdNum())
                .name(touristDto.getName())
                .city(touristDto.getCity())
                .stateCode(touristDto.getStateCode())
                .countryCode(touristDto.getCountryCode())
                .date(touristDto.getDate())
                .lat(touristDto.getLat())
                .lon(touristDto.getLon())
                .build();
        return tourist;
    }
}
